//-------------------------------------------------------------------
// Modify this file to Change all intial Settings
//-------------------------------------------------------------------


//-------------------------------------------------
// Soft Limit Window
//-------------------------------------------------
#define LIMIT_X_MIN -24.0
#define LIMIT_X_MAX 0.05

#define LIMIT_Y_MIN -39.0
#define LIMIT_Y_MAX 0.1

#define LIMIT_Z_MIN -7.0
#define LIMIT_Z_MAX 0.0

#define LIMIT_A_MIN -1000000
#define LIMIT_A_MAX 1000000

#define LIMIT_B_MIN -1000000
#define LIMIT_B_MAX 1000000

#define LIMIT_C_MIN -1000000
#define LIMIT_C_MAX 1000000

//-------------------------------------------------
// Units per Inch & Jog/Homing speed
//-------------------------------------------------
#define STEPS_PER_IN_X 25400
#define STEPS_PER_IN_Y 25400
#define STEPS_PER_IN_Z 25400
#define STEPS_PER_IN_A 10000
#define STEPS_PER_IN_B 10000
#define STEPS_PER_IN_C 10000

#define HOME_SPEED_X 20000
#define HOME_SPEED_Y 20000
#define HOME_SPEED_Z 20000
#define HOME_SPEED_A 20000
#define HOME_SPEED_B 5000
#define HOME_SPEED_C 5000

#define JOG_SPEED_0 20000
#define JOG_SPEED_1 30000
#define JOG_SPEED_2 50000

#define REV_DIR_X 0
#define REV_DIR_Y 0
#define REV_DIR_Z 0
#define REV_DIR_A 0
#define REV_DIR_B 0
#define REV_DIR_C 0

#define HOME_DIR_X 1
#define HOME_DIR_Y 1
#define HOME_DIR_Z 1
#define HOME_DIR_A 0
#define HOME_DIR_B 0
#define HOME_DIR_C 0

#define HOME_ACT_LOW_X 0
#define HOME_ACT_LOW_Y 0
#define HOME_ACT_LOW_Z 0
#define HOME_ACT_LOW_A 0
#define HOME_ACT_LOW_B 0
#define HOME_ACT_LOW_C 0

#define HOME_INDEX_X 0
#define HOME_INDEX_Y 0
#define HOME_INDEX_Z 0
#define HOME_INDEX_A 0
#define HOME_INDEX_B 0
#define HOME_INDEX_C 0

#define HOME_EN_X 1
#define HOME_EN_Y 1
#define HOME_EN_Z 1
#define HOME_EN_A 0
#define HOME_EN_B 0
#define HOME_EN_C 0

#define HOME_MODE 0  // 0 => Z, XY  1 => Z, Y&A, X  2 => Z, X&A, Y

#define HOME_OFFSET_X 0.0
#define HOME_OFFSET_Y 0.0
#define HOME_OFFSET_Z 0.0
#define HOME_OFFSET_A 0.0
#define HOME_OFFSET_B 0.0
#define HOME_OFFSET_C 0.0

#define SLAVE_A_TO -1
#define SLAVE_B_TO -1

//-------------------------------------------------
#define EXPAND_IO_EN 1

//-------------------------------------------------
// Motor Tunning
//-------------------------------------------------
#define MAX_VEL_X 50000.0
#define MAX_VEL_Y 50000.0
#define MAX_VEL_Z 50000.0
#define MAX_VEL_A 50000.0
#define MAX_VEL_B 20000.0
#define MAX_VEL_C 20000.0

#define MAX_ACCEL_X 200000.0
#define MAX_ACCEL_Y 200000.0
#define MAX_ACCEL_Z 200000.0
#define MAX_ACCEL_A 200000.0
#define MAX_ACCEL_B 200000.0
#define MAX_ACCEL_C 200000.0

#define MAX_JERK_X 600000.0
#define MAX_JERK_Y 600000.0
#define MAX_JERK_Z 600000.0
#define MAX_JERK_A 600000.0
#define MAX_JERK_B 600000.0
#define MAX_JERK_C 600000.0


#define GAIN_P_X 0.80
#define GAIN_P_Y 0.80
#define GAIN_P_Z 0.80
#define GAIN_P_A 0.80
#define GAIN_P_B 0.80
#define GAIN_P_C 0.80

#define GAIN_I_X 0.00001
#define GAIN_I_Y 0.00001
#define GAIN_I_Z 0.00001
#define GAIN_I_A 0.00001
#define GAIN_I_B 0.00001
#define GAIN_I_C 0.00001

#define GAIN_D_X 40
#define GAIN_D_Y 40
#define GAIN_D_Z 40
#define GAIN_D_A 40
#define GAIN_D_B 40
#define GAIN_D_C 40

#define FF_ACEL_X 0.0
#define FF_ACEL_Y 0.0
#define FF_ACEL_Z 0.0
#define FF_ACEL_A 0.0
#define FF_ACEL_B 0.0
#define FF_ACEL_C 0.0

#define FF_VEL_X 0.006
#define FF_VEL_Y 0.006
#define FF_VEL_Z 0.006
#define FF_VEL_A 0.006
#define FF_VEL_B 0.006
#define FF_VEL_C 0.006

#define MAX_FOLLOW_ERROR_X 1000.0
#define MAX_FOLLOW_ERROR_Y 1000.0
#define MAX_FOLLOW_ERROR_Z 1000.0
#define MAX_FOLLOW_ERROR_A 1000.0
#define MAX_FOLLOW_ERROR_B 1000.0
#define MAX_FOLLOW_ERROR_C 1000.0
