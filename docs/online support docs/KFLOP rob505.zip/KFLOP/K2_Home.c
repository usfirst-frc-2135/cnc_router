#include "KMotionDef.h"
#define HomingStart 1026
#define HOMING_PERSIST 13

int main() 
{
	ClearBit(HomingStart);	
	Delay_sec(0.5);
	SetBit(HomingStart);
    return 0;
}
