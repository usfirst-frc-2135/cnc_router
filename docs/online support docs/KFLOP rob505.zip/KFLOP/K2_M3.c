#include "KMotionDef.h"

#define WAIT_TIME 1.0

#define pSpindleFWD 34

int main() 
{
    SetBit(pSpindleFWD);
    Delay_sec(WAIT_TIME);
    
    return 0;
}
