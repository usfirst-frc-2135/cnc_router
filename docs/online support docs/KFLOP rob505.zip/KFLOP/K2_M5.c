#include "KMotionDef.h"

#define WAIT_OFF_TIME 0.01

#define pSpindleFWD 34

int main() 
{
    Delay_sec(WAIT_OFF_TIME);

    ClearBit(pSpindleFWD);    

    return 0;
}
