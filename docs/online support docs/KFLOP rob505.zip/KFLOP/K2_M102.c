#include "KMotionDef.h"
#include "driver/defines.h"

int main() 
{
    SetBit(pOscKnifeON);    
 
    return 0;
}
