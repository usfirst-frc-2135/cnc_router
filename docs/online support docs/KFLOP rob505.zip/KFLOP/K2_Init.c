#include "KMotionDef.h"
#include "driver/defines.h"
#include "driver/util.h"

int main() 
{
	// Stop Homing
	ClearBit(vbHomeRunning);	
    
	// Use Values from "\KFLOP\K2_Settings.h"
	DefaultPersist();

	return 0;	
}
