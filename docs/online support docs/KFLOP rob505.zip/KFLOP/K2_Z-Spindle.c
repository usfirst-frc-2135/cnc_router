#include "KMotionDef.h"
#include "driver/defines.h"

// Switch To Toolchange Spindl and turn off Tangental Knife

#define X 0
#define Y 1
#define Z 2
#define A 3
#define B 4

main()
{	
	if (!ReadBit(vbMachineHomed))	// Cancel Op. If machine has not home yet.
		return;
		
	Move(Z, 0);
	Move(A, 0);
	
	while(!CheckDone(Z))
		;
	while(!CheckDone(A))
		;
		 
	ClearBit(pTangentMode);
	Delay_sec(0.5); // Wait for mode to change

}
