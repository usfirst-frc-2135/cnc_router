#include "KMotionDef.h"
#include "driver/defines.h"

main()
{
	while(1)
	{
		
		if (ReadBit(vbExpandIn0))
			ClearBit(vbExpandOut0);
		else
			SetBit(vbExpandOut0);

		if (ReadBit(vbExpandIn1))
			ClearBit(vbExpandOut1);
		else
			SetBit(vbExpandOut1);

		if (ReadBit(vbExpandIn2))
			ClearBit(vbExpandOut2);
		else
			SetBit(vbExpandOut2);

		if (ReadBit(vbExpandIn3))
			ClearBit(vbExpandOut3);
		else
			SetBit(vbExpandOut3);

		if (ReadBit(vbExpandIn4))
			ClearBit(vbExpandOut4);
		else
			SetBit(vbExpandOut4);

		if (ReadBit(vbExpandIn5))
			ClearBit(vbExpandOut5);
		else
			SetBit(vbExpandOut5);

		if (ReadBit(vbExpandIn6))
			ClearBit(vbExpandOut6);
		else
			SetBit(vbExpandOut6);

		if (ReadBit(vbExpandIn7))
			ClearBit(vbExpandOut7);
		else
			SetBit(vbExpandOut7);
	}
}
