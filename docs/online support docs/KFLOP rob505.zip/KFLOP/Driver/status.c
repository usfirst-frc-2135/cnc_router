//----------------------------------------------------------------
// KFLOP Status routine
// K2CNC - Copyright 2013
// Version: 2.0.2
//
// - status.c  -> Thread 1
//----------------------------------------------------------------
// Last Modified: 4-24-2013
//
// ToDo: 
//
//----------------------------------------------------------------

#include "KMotionDef.h"
#include "defines.h"
#include "pthread.h"
#include "util.h"
#include "events.h"

//----------------------------------------------------------------
main()
{
	switch (UserDataToDouble(pdControlType))
	{
		case TYPE_DC_STEP_DIR:
			printf("Type: STEP_DIR\n");
			break;
		case TYPE_AC_SERVO_STEP_DIR:
			printf("Type: AC_SERVO_STEP_DIR\n");
			break;
		case TYPE_AC_SERVO_ANALOG:
			printf("Type: AC_SERVO_ANALOG\n");
			break;
		case TYPE_DC_SERVO:
			printf("Type: DC_SERVO\n");
			break;
		case TYPE_DC_SERVO_REV4:
			printf("Type: DC_SERVO_REV4\n");
			break;
	}

	printf("FirmwareVersion: %d\n", UserDataToDouble(pdFirmwareVersion));
	
	DoubleToUserData(146, 123.456);

}
