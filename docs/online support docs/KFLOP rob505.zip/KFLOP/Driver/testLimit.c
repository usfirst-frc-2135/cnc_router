#include "KMotionDef.h"
#include "defines.h"
#include "pthread.h"
#include "util.h"
#include "events.h"

//----------------------------------------------------------------
main()
{
	while (1)
	{
		if (ch0->Dest < 0)
		{
			Jog(0, 0);
			//sMove(0,0);
		}
	}


}
