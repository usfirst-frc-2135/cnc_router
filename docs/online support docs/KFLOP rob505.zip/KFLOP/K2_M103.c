#include "KMotionDef.h"
#include "driver/defines.h"

int main() 
{
    ClearBit(pOscKnifeON);    
    
    return 0;
}
